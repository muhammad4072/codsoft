        <!-- Right column -->


<div id="col" class="noprint">
            <div id="col-in">

                <!-- About Me -->
                <h3>Welcome</h3>

                <div id="about-me">
                    <p>Administrator<br />
                    </p>
              </div> <!-- /about-me -->

                <hr class="noscreen" />

                <!-- Category -->
                <h3 >&nbsp;</h3>

              <br/>

      <hr class="noscreen" />

                <!-- Archive -->
                <h3>&nbsp;</h3>

                <br/>

            <hr class="noscreen" />

                <!-- Links -->
                <h3>&nbsp;</h3>
<br/>

<hr class="noscreen" />
          </div> <!-- /col-in -->
</div> 
<!-- /col -->
